"use strict";

// Create the sidepanel for the React App to use
const sidepanel = document.createElement("div");
sidepanel.setAttribute("id", "root");
document.body.appendChild(sidepanel);
